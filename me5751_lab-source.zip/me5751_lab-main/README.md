# The package is for ME5751 Simulation. Want to have a ROS version? 
[Course website](https://sites.google.com/view/cppme5751/home)

# History and credit
## HMC E160 Spring 2017, Spring 2018

HMC E160 Autonomous robots navigation, without using ROS
Instructor: C. Clark, Assistants: Z. Lobo, J. Lee

## HMC E190AR Spring 2019
HMC E190AR Robotics with ROS, a version with ROS is available (not included in this package)
Instructor: Y. Chang, Assistants: J. Shi, J. Lee

## CPP ME5751 Fall 2019
2019 CPP ME 5751 Robot motion planning, simulation only
Instructor: Y. Chang

## CPP ME5751 Fall 2022
2022 CPP ME 5751 Robot motion planning, simulation only
Instructor: Y. Chang