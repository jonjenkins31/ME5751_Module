

#### WELCOME

 This is the project files team octopus for ME 5751. Lab number #1 Module #1  Cal poly pomona fall 2022. By jonathan Jenkins and Erik Duque
 
 



___

The following is a breakdown of the different folders and the files contained in them:

1. **Program**
   - *Project Files*
    all the program files for this project including the custom P_controler python file

   
    &nbsp;
2. **Use Logs**  
   - *CSV*
    All the exported files grom the project that was used in the report
      
   - *Excel*
    The excel files used to create graphs for the report
    

    &nbsp;
3. **P_Controler**
   - *P_Controler file*
    A copy of the custom P_controler that we made. Exactly the same as the one located in the Program folder

  
    &nbsp;
4. **Final Report**
     
   - *Module 1 Final Lab Report*
    PDF export of the submited lab report 
    

> Note: Updating the lab report onto canvas . will also include a zip file of the custom program. 


**ENJOY!!**



