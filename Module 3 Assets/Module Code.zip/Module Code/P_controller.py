#!/usr/bin/python
# -*- coding: utf-8 -*-

from E160_state import *
from E160_robot import *
import math
import time


class P_controller:

	def __init__(self, robot, logging = True):
		self.robot = robot  # do not delete this line
		self.kp = 3  # k_rho
		self.ka = 8  # k_alpha
		self.kb = -1.5  # k_beta
		self.logging = logging

		if(logging == True):
			self.robot.make_headers(['pos_X','posY','posZ','vix','viy','wi','vr','wr'])

		self.set_goal_points()

	#Edit goal point list below, if you click a point using mouse, the points programmed
	#will be washed out
	def set_goal_points(self):
# here is the example of destination code
  		#------------Triangle----
		#self.robot.state_des.add_destination(x=-150,y=-100,theta=0)    	#goal point 1 TOP LEFT
		#self.robot.state_des.add_destination(x=0,y=100,theta=0)   		#goal point 2 BOT MIDDLE
		#self.robot.state_des.add_destination(x=150,y=-100,theta=0)   	#goal point 3 BOT RIGHT
		#------------square----
		#self.robot.state_des.add_destination(x=160,y=0,theta=-math.pi/2)    	#goal point 1 TOP RIGHT  (theta in radians)
		#self.robot.state_des.add_destination(x=0,y=-160,theta=-math.pi)   	#goal point 2 BOT RIGHT
		#self.robot.state_des.add_destination(x=-160,y=0,theta=math.pi/2)   	#goal point 3 BOT LEFT
		#self.robot.state_des.add_destination(x=0,y=160,theta=0)     	#goal point 4 TOP LEFT
		#------------square----
		self.robot.state_des.add_destination(x=10,y=10,theta=math.pi/8) #goal point 1
		self.robot.state_des.add_destination(x=20,y=20,theta=-math.pi/4) #goal point 2
		self.robot.state_des.add_destination(x=20,y=30,theta=math.pi/2) #goal point 3




	def track_point(self):
     	# REV 5.0 (w/ homogenious transform)
		#  Most of your program should be here, compute rho, alpha and beta using d_pos and c_pos

		#------------Main PController Code-------------------------------------------------------------------

		#STEP 1:  begin by pulling current  position, velocity data 
		# All d_ means destination
		(d_posX, d_posY, d_theta) = self.robot.state_des.get_des_state()  # get next destination configuration
		# All c_ means current_
		(c_posX, c_posY, c_theta) = self.robot.state.get_pos_state()  # get current position configuration
		(c_vix, c_viy, c_wi) = self.robot.state.get_global_vel_state() #get current velocity configuration, in the global frame
		(c_v, c_w) = self.robot.state.get_local_vel_state() #get current local velocity configuration


		
		#------------Not currently used-------------------------------------------------------------------
		#STEP 2:  Calculate robot pos in terms of Goal reference position 
  		#GLOBAL TO ROBOT TRANSFORM
		RobotH =np.array([[math.cos(c_theta),-math.sin(c_theta),0,c_posX],
  				[math.sin(c_theta),math.cos(c_theta),0,c_posY],
      			[0,0,1,0],
          		[0,0,0,1]])  #  Translation with x and y Rotate z-axis (delta) TxyRz
  		#GLOBAL TO GO TRANSFORM
		GoH =np.array([[math.cos(d_theta),-math.sin(d_theta),0,d_posX],
  				[math.sin(d_theta),math.cos(d_theta),0,d_posY],
      			[0,0,1,0],
          		[0,0,0,1]]  )  #  Translation with x and y Rotate z-axis (delta) TxyRz
		#Globe frame TO GO frame  TRANSFORM
		invGoH = np.linalg.inv(GoH) 
		P_globe_robot= np.array([[c_posX],[c_posY],[0],[1]]) 		# Robot location with respects of robot global frame
		P_go_robot= invGoH.dot(P_globe_robot) 						# Robot location with respects to go frame
		dx_go_robot= P_go_robot[0][0]						 #  First element of first row
		dY_go_robot= P_go_robot[1][0]						 #  First element of second row
    	#Globe frame TO Robot frame  TRANSFORM
		invRobotH = np.linalg.inv(RobotH) 
		P_globe_go= np.array([[d_posX],[d_posY],[0],[1]]) 		# Robot location with respects of robot global frame
		P_robot_go= invRobotH.dot(P_globe_go) 				# Robot location with respects to go frame
		dx_robot_go= P_robot_go[0][0]						 #  First element of first row
		dY_robot_go= P_robot_go[1][0]						 #  First element of second row
		#------------------------------------------------------------------------------

 		 #STEP 3:  Calculate the rho, alpha, and beta of the system at the current instance
		# Most of your program should be here, compute rho, alpha and beta using d_pos and c_pos
		rho=math.sqrt((d_posX-c_posX)**2+(d_posY-c_posY)**2)
		omega=math.atan2(d_posY-c_posY,d_posX-c_posX)
		alpha=omega-c_theta
		#rho= math.sqrt((dx_robot_go)**2+(dY_robot_go)**2) 		# distance between robot's current location and the desired location---- in robot frame
		#alpha= math.atan2((dY_robot_go),(dx_robot_go))         	# angle between robot's XR axis and the rho vector---- in robot frame
		#beta= -(d_theta-c_theta)- alpha      	# angle between rho vector and the Xg axis---- in robot frame
		
  		#STEP 4:  Regulate the rho, alpha, and beta of the system at the current instance. limit within -/+ pi/2
        # Determine if forward or backwards method is to be used
		if (- math.pi/2 < alpha ) and (alpha <= math.pi/2):
			beta = d_theta - omega # beta=omega-d_theta
			c_v= self.kp*rho
		else:
			omega=math.atan2(d_posY-c_posY,c_posX-d_posX)
			beta= -(omega + d_theta)  # beta= omega + d_theta
			alpha =  c_theta + beta # - c_theta - betas
			c_v= -self.kp*rho
		

		# set new c_v = k_rho*rho, c_w = k_alpha*alpha + k_beta*beta

		#STEP 5A: # Set Robot Linear and Anglular Velocity
		# self.robot.set_motor_control(linear velocity (cm), angular velocity (rad))
		c_w=self.ka*alpha + self.kb*beta
        # Limit Robot velocity
		if c_v > 100: c_v = 100
		if c_v < -100: c_v = -100
		# Limit Robot angular velocity
		if abs(c_w) > 50:
			if abs(c_w) == 50:
				c_w = 50
			else:
				c_w = -50		
		self.robot.set_motor_control(c_v, c_w)  # use this command to set robot's speed in local frame


		#STEP 5B: # WHEEL SPEED 
		# you need to write code to find the wheel speed for your c_v, and c_w, the program won't calculate it for you.
		# my fun attempt Deas
		phi_l =round( (1/3)*c_v +4*c_w ,2 )
		phi_r =round( (1/3)*c_v -4*c_w ,2 )
		# Limit Wheel Angular Velocity 
		if phi_l > 16: phi_l =16
		if phi_l < -16: phi_l = -16
		if phi_r > 16: phi_r = 16
		if phi_r < -16: phi_r = -16
		self.robot.send_wheel_speed(phi_l,phi_r) #unit rad/sw
		
				
  		#STEP 6: # reach way point criteria
		#you need to modify the reach way point criteria
		if  abs(d_theta-c_theta) < 1 and abs(rho) < 1 : #you need to modify the reach way point criteria
			self.robot_destination_reached = True
		else:
			self.robot_destination_reached = False

		#--------------------------------------------------------------------------------------------------

		# use the following to log the variables, use [] to bracket all variables you want to store
		# stored values are in log folder
		if self.logging == True:
			self.robot.log_data([c_posX,c_posY,c_theta,c_vix,c_viy,c_wi,c_v,c_w])

		if (self.robot_destination_reached) == True: #you need to modify the reach way point criteria
			if(self.robot.state_des.reach_destination()): 
				print("final goal reached")
				self.robot.set_motor_control(.0, .0)  # stop the motor
				return True
			else:
				print("one goal point reached, continute to next goal point")
		
		return False